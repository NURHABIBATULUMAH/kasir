<div class="card mt-5">
	<div class="card-body">
<p>Data Barang
	</div>
</div>